library(data.table)
library(readxl)
EastWestAirlines <- read_xlsx("G:/practical data science/Assignments of data science/Assignments of Data science/Assignment no.4/EastWestAirlines.xlsx", sheet="data")
View(EastWestAirlines)
colnames(EastWestAirlines)
ncol(EastWestAirlines)
sub_EastWestAirlines <-EastWestAirlines[,2:12]
norm_airline <-scale(sub_EastWestAirlines)
# Hirerachical CLustering
distanct_airline <-dist(norm_airline,method = "euclidean")
str(distanct_airline)
airline_clust <-hclust(distanct_airline,method = "complete")
plot(airline_clust, hang = -1)
group_airline <-cutree(airline_clust,k=5)
EastWestAirlines_New <-cbind(EastWestAirlines,group_airline)
setnames(EastWestAirlines_New,'group_airline','group_hclust')
aggregate(EastWestAirlines_New[,2:12], by = list(EastWestAirlines_New$group_hclust),FUN = mean)
# K-MEANS CLustering
airline_kmeans <-kmeans(norm_airline,5)
str(airline_kmeans)
airline_kmeans$centers
EastWestAirlines_New <-cbind(EastWestAirlines_New,airline_kmeans$cluster)
colnames(EastWestAirlines_New)
#Aggregrate
aggregate(EastWestAirlines_New[,2:12],by= list(EastWestAirlines_New$`airline_kmeans$cluster`), FUN = mean)
#install packages("cluster")
library(cluster)
# Using Clara function(Clustering for Large Applications) to find cluster
xcl <- clara(norm_airline,5)#using Centroid
clusplot(xcl)
#using Partition Arround Medoids to find cluster
xpm <- pam(norm_airline,5) # Using Medoids
clusplot(xpm)
